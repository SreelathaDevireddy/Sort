#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

#include "SortInterface.h"

class SelectionSort : public SortInterface
{
	public:
		void sort(int array[], int size);
	private:
		int getMinElementIndex(int array[], int beginIndex, int endIndex);
};

#endif
