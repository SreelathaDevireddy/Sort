#ifndef SORTINTERFACE_H
#define SORTINTERFACE_H

#include <algorithm>

class SortInterface
{
	public:
		virtual void sort(int array[], int size) = 0;
};

#endif
