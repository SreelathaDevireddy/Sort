#ifndef QUICKSORT_H
#define QUICKSORT_H

#include "SortInterface.h"

class QuickSort : public SortInterface
{
	public:
		void sort(int array[], int size);
	
	private:
		int partition(int array[], int beginIndex, int endIndex);
		void recursiveQsort(int array[], int begin, int end);
};

#endif
