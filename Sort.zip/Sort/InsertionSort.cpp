#include "InsertionSort.h"

void InsertionSort :: sort(int array[], int size)
{
	int i, j, tmp;
	
	for(i = 1; i < size; i++)
	{
		tmp = array[i];
		j = i;
		while (j > 0 && array[j-1] > tmp)
		{
			array[j] = array[j-1];
			j = j -1;
 		}
 		array[j] = tmp;
 	}
}
