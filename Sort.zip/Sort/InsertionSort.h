#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

#include "SortInterface.h"

class InsertionSort : public SortInterface
{
	public:
		void sort(int array[], int size);
};

#endif
