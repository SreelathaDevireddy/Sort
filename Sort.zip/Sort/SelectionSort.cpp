#include "SelectionSort.h"

int SelectionSort :: getMinElementIndex(int array[], int beginIndex, int endIndex)
{
	int minElemIndex, searchIndex;
	
	minElemIndex = beginIndex;
	
	for(searchIndex = beginIndex+1; searchIndex <= endIndex; searchIndex++)
	{
		if(array[searchIndex] < array[minElemIndex])
			minElemIndex = searchIndex;
	}
	return minElemIndex;
}

void SelectionSort :: sort(int array[], int size)
{
	int minElemIndex;
	int sortIndex;
	
	for(sortIndex = 0; sortIndex < size; sortIndex++)
	{
		minElemIndex = getMinElementIndex(array, sortIndex, size-1);
		std::swap(array[sortIndex], array[minElemIndex]);
	}
}
