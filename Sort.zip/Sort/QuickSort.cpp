
#include "QuickSort.h"


int QuickSort :: partition(int array[], int beginIndex, int endIndex)
{
	int pivot;
	int upperIndex, lowerIndex;
	
	int mid = (beginIndex + endIndex) / 2;
	pivot = array[mid];
	std::swap(array[mid], array[beginIndex]);
	
	lowerIndex = beginIndex+1;
	upperIndex = endIndex;
	while(lowerIndex <= upperIndex)
	{
		while( lowerIndex <= upperIndex && array[lowerIndex] <= pivot)
		{
			lowerIndex++;
		}
		while(lowerIndex <= upperIndex && array[upperIndex] > pivot)
		{
			upperIndex--;
		}
		if(lowerIndex < upperIndex)
		{
			std::swap(array[lowerIndex], array[upperIndex]);
		}
	}
	std::swap(array[lowerIndex-1], array[beginIndex]);
	return lowerIndex-1;
}

void QuickSort :: recursiveQsort(int array[], int begin, int end)
{
	int pivotIndex;
	if (begin < end)
	{
		pivotIndex = partition(array, begin, end);
		recursiveQsort(array, begin, pivotIndex);
		recursiveQsort(array, pivotIndex+1, end);
	}
}

void QuickSort :: sort(int array[], int size)
{
	recursiveQsort(array, 0, size-1);
}
